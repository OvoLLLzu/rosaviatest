package com.example.atplquiz;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
